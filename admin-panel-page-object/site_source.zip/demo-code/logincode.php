<?php
$page_title="free PHP source code for the login example page";
$page_keywords="php source code, login php source code";
$page_desc="Free PHP source code for login page";
include("header.inc");
?>

<p align="center">This page shows the PHP and JavaScript code used in the
&quot;Login&quot; section.</p>

<div align="center"><strong>login.php</strong><div align="left" style="border:solid 2px #0000FF; background:#EAEDFC; color:#000000; padding:2px; width:800px; height:300px; overflow:auto;"> <?php show_source("addauser.php"); ?> </div></div><br>

<div align="center"><strong>getresult.inc</strong><div align="left" style="border:solid 2px #0000FF; background:#EAEDFC; color:#000000; padding:2px; width:800px; height:300px; overflow:auto;"> <?php show_source("getresult.inc"); ?> </div></div><br>

<p align="center"><a href="javascript:history.go(-1)">&lt; Go Back&lt;</a></p>


<?php include("footer.inc"); ?>