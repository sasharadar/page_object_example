<table border="0" width="260">
  <tr>
    <td width="93"><strong><a href="http://www.thedemosite.co.uk/demo-code.zip"><img
    src="http://www.thedemosite.co.uk/download-these-php-demo-pages.jpg" width="93"
    height="85" alt="download-the-login-demo-pages" border="0"></a></strong></td>
    <td width="167">
    <small><strong><font color="#008000"><a href="http://www.thedemosite.co.uk/demo-code.zip">FREE Download</a>
    <br>complete LOGIN<br>demo pages<br>
    of this website<br><small>
    <em>Size: 27 Kbytes</em></font></strong>
    </small></small>
    </td>
  </tr>
</table>
