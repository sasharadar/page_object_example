<?php
// from: http://php.thedemosite.co.uk/
// version 1.2
define('DBHOST', 'localhost');// MySQL host address - localhost is usually fine
define('DBUSER', ''); // db username
define('DBPASS', ''); // db password
define('DBNAME', ''); // db name

define('DEBUG', false);// set to false when done testing

define('CHARSET',"utf8"); // sets the charset of your database for communication
define('DBDRIVER', 'mysql');// database driver to use
define('DBPORT', '3306'); // database port for connection
